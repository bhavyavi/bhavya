<div>

    <h2 align="center">Cash on Delivery</h2>

</div>
