<?php

include_once "functions.php";


$db->getCats();
$db->getBrands();
$db->getPro();
$db->getCatPro();
$db->getBrandPro();
$db->cart();
$db->total_items();
$db->total_price();

?>
